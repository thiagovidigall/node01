const Query = require('./Query')
const Usuario = require('./Usuario')
const Mutation = require('./Mutation')

module.exports = {
    Query,
    Mutation,
    Usuario
}